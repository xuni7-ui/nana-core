import{c as n}from"./x-DoR-YGqy.js";import{r as o}from"./index-BZbiJHKu.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const m=n("House",[["path",{d:"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8",key:"5wwlr5"}],["path",{d:"M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",key:"1d0kgt"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const i=n("Menu",[["line",{x1:"4",x2:"20",y1:"12",y2:"12",key:"1e0a9i"}],["line",{x1:"4",x2:"20",y1:"6",y2:"6",key:"1owob3"}],["line",{x1:"4",x2:"20",y1:"18",y2:"18",key:"yk5zj1"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=n("Orbit",[["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}],["circle",{cx:"19",cy:"5",r:"2",key:"mhkx31"}],["circle",{cx:"5",cy:"19",r:"2",key:"v8kfzx"}],["path",{d:"M10.4 21.9a10 10 0 0 0 9.941-15.416",key:"eohfx2"}],["path",{d:"M13.5 2.1a10 10 0 0 0-9.841 15.416",key:"19pvbm"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y=n("Settings",[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]),a={theme:"system",motion:!0,avatar:!0,fontScale:1,quiet:!0,language:"zh-CN"};function d(){const[t,r]=o.useState(()=>{try{const e=JSON.parse(localStorage.getItem("nana-space.preferences.v1")||"{}");return{...a,theme:["dark","light","system"].includes(e.theme)?e.theme:a.theme,motion:typeof e.motion=="boolean"?e.motion:a.motion,avatar:typeof e.avatar=="boolean"?e.avatar:!0,fontScale:[.9,1,1.1,1.2].includes(e.fontScale)?e.fontScale:1,quiet:typeof e.quiet=="boolean"?e.quiet:!0}}catch{return a}});return o.useEffect(()=>{const e=matchMedia("(prefers-color-scheme: dark)"),c=()=>{document.documentElement.dataset.theme=t.theme==="system"?e.matches?"dark":"light":t.theme,document.documentElement.dataset.motion=t.motion?"full":"reduced",document.documentElement.style.fontSize=`${16*t.fontScale}px`,document.documentElement.style.setProperty("--v3-font-scale",String(t.fontScale))};c(),e.addEventListener("change",c);try{localStorage.setItem("nana-space.preferences.v1",JSON.stringify(t))}catch{}return()=>e.removeEventListener("change",c)},[t]),[t,r]}export{m as H,i as M,u as O,y as S,d as u};
