"""Versioned context-based ModelPort. Model instances are disposable resources.

The original reading-only ports.ModelPort remains compatible. This v2 contract
adds general state context, rather than encoding continuity in a rationale string.
No response here can contain a Grant, Receipt, success state or Store mutation.
"""
import json
from typing import Literal, Protocol

from pydantic import Field,model_serializer,model_validator

from ..contracts import CoreError, DTO
from .autonomy.private_intent import PrivateQuestionProposal,PrivatePlanProposal,PrivateTendencyProposal
from .subject.opportunities import Behavior,LearningProgramRef


class FrozenModelInput(DTO):
    schema_version: Literal[2] = 2
    task_class: str
    context_json: str
    context_digest: str


class CognitiveProposal(DTO):
    model_config={**DTO.model_config, "hide_input_in_errors":True}
    # Optional current-process association, not a memory, fact, goal or a
    # request to persist. C may simply let it end in this cognition.
    passing_thought:str|None=Field(default=None,min_length=1,max_length=512)
    # A candidate direction within the current C frame, not an action/authority.
    preferred_behavior:Behavior|None=None
    learning_program_ref:LearningProgramRef|None=Field(default=None,
        description='Exact entry from SUBJECT_APPRAISAL.learning_programs, required when choosing its LEARN option. Learning is optional; this is not a learned result or permission.')
    private_question:PrivateQuestionProposal|None=None
    private_plan:PrivatePlanProposal|None=None
    private_tendency:PrivateTendencyProposal|None=None
    schema_version: Literal[2] = 2
    identity_id: str
    identity_revision: int = Field(ge=1)
    interpretation: str = Field(min_length=1, max_length=2048)
    proposed_operations: tuple[Literal["READ_SOURCE", "LOCATE_SOURCE", "DRAFT", "ASK", "WAIT"], ...] = Field(min_length=1, max_length=8)
    memory_refs: tuple[str, ...] = Field(default=(), max_length=64)
    lesson_refs: tuple[str, ...] = Field(default=(), max_length=32)

    @model_validator(mode='after')
    def one_private_edit(self):
        if self.learning_program_ref is not None and (self.preferred_behavior!='LEARN' or any(v is not None for v in (self.private_question,self.private_plan,self.private_tendency))):
            raise ValueError('a learning selection requires LEARN without a simultaneous private edit')
        if sum(v is not None for v in (self.private_question,self.private_plan,self.private_tendency))>1:
            raise ValueError('one private edit per formation intention; existing thoughts coexist')
        return self

    @model_serializer(mode='wrap')
    def compatible_wire(self,handler):
        value=handler(self)
        if self.passing_thought is None:value.pop('passing_thought',None)
        if self.preferred_behavior is None:value.pop('preferred_behavior',None)
        if self.learning_program_ref is None:value.pop('learning_program_ref',None)
        if self.private_question is None:value.pop('private_question',None)
        if self.private_plan is None:value.pop('private_plan',None)
        if self.private_tendency is None:value.pop('private_tendency',None)
        return value


class ContinuityModelPort(Protocol):
    descriptor: str
    def propose(self, request: FrozenModelInput) -> str: ...


class DeliberationResult(DTO):
    resource_record_id:str|None=None
    model_descriptor: str
    context_digest: str
    raw_proposal_json: str
    proposal: CognitiveProposal
    execution: Literal["NOT_EXECUTED"] = "NOT_EXECUTED"

    @model_serializer(mode='wrap')
    def compatible_resource(self,handler):
        result=handler(self)
        if self.resource_record_id is None:result.pop('resource_record_id',None)
        return result


def validate_resource_record(store,rid,proposal,*,scope,subject_event_id,privacy_classes):
    """An adapter audit pointer is not authority; bind its exact original reply."""
    from .records import RecordService
    from ..storage import digest
    records=RecordService(store);head=store.one('continuity_records',rid)
    if (not head or head['record_kind']!='COGNITION_PROPOSAL' or head['scope']!=scope
            or head['privacy_class'] not in privacy_classes or not records.current_support(rid)):
        raise CoreError('SUBJECT_RESOURCE_BINDING_INVALID')
    payload=records.read(rid)['payload'];request=store.one('cognitive_requests',payload['reply']['request_id'])
    if (not request or request['state']!='PROPOSED' or payload.get('subject_candidate_digest')!=digest(proposal.model_dump(mode='json'))):
        raise CoreError('SUBJECT_RESOURCE_BINDING_INVALID')
    body=records.read(request['record_id'])['payload']['request']
    from .subject.state import revision
    lease=store.one('runtime_lease',store.identity['identity_id'])
    if (not lease or request['owner_epoch']!=lease['epoch'] or request['subject_revision']!=revision(store)
            or body['cognitive_role']!='SELF' or body['role_input'].get('subject_cognition',{}).get('subject_event_id')!=subject_event_id):
        raise CoreError('SUBJECT_RESOURCE_BINDING_INVALID')
    return rid


def validate_cognitive_proposal(proposal, context):
    """One reference/identity contract for original C and its provider resource."""
    manifest=context.manifest
    if (proposal.identity_id,proposal.identity_revision)!=(manifest.identity_id,manifest.identity_revision):
        raise CoreError('MODEL_IDENTITY_MISMATCH')
    available={m for b in context.blocks for m in b.source_memory_ids}
    lessons={json.loads(b.data_json)['lesson_id'] for b in context.blocks if b.kind=='LESSON'}
    if not set(proposal.memory_refs)<=available or not set(proposal.lesson_refs)<=lessons:
        raise CoreError('UNSUPPORTED_COGNITIVE_REFERENCE')
    if proposal.preferred_behavior is not None:
        choices={choice for b in context.blocks if b.kind=='SUBJECT_APPRAISAL' for choice in json.loads(b.data_json).get('behavior_options',())}
        if proposal.preferred_behavior not in choices:raise CoreError('UNSUPPORTED_COGNITIVE_BEHAVIOR')
    programs=[p for b in context.blocks if b.kind=='SUBJECT_APPRAISAL' for p in json.loads(b.data_json).get('learning_programs',())]
    selected=proposal.learning_program_ref
    if selected is not None and not any((p['learning_key'],p['spec_digest'])==(selected.learning_key,selected.spec_digest) for p in programs):
        raise CoreError('UNSUPPORTED_COGNITIVE_LEARNING_PROGRAM')
    if programs and proposal.preferred_behavior=='LEARN' and selected is None:
        raise CoreError('PRIVATE_LEARNING_SELECTION_REQUIRED')
    for candidate,category in ((proposal.private_question,'PRIVATE_QUESTION'),(proposal.private_plan,'PRIVATE_PLAN'),(proposal.private_tendency,'PRIVATE_TENDENCY')):
        if candidate is None:continue
        private_refs={rid for b in context.blocks if b.kind=='PRIVATE_INTERNAL_STATE' for rid in b.source_record_ids}
        if not set(candidate.related_private_record_ids)<=private_refs:raise CoreError('UNSUPPORTED_'+category+'_REFERENCE')
        if candidate.revises_record_id is not None:
            target=next((json.loads(b.data_json) for b in context.blocks if b.kind=='PRIVATE_INTERNAL_STATE' and candidate.revises_record_id in b.source_record_ids),None)
            if target is None or target['category']!=category:raise CoreError('UNSUPPORTED_'+category+'_REVISION')


class DeliberationSession:
    def __init__(self, assembler):
        self.assembler = assembler

    def run(self, model: ContinuityModelPort, context, request, policy):
        self.assembler.validate(context, request, policy)
        envelope = FrozenModelInput(task_class=request.task_class,
            context_json=context.model_dump_json(), context_digest=context.content_digest)
        # The adapter gets immutable serialized data, no service/authority handles.
        raw = model.propose(envelope)
        if type(raw) is not str or len(raw.encode()) > 32768:
            raise CoreError("INVALID_COGNITIVE_REPLY")
        proposal = CognitiveProposal.model_validate_json(raw)
        validate_cognitive_proposal(proposal,context)
        self.assembler.validate(context, request, policy)  # state may change during inference
        return DeliberationResult(model_descriptor=model.descriptor, context_digest=context.content_digest,
                                  raw_proposal_json=raw, proposal=proposal,resource_record_id=getattr(model,'resource_record_id',None))


class AnalyticalFixturePort:
    """Deterministic structured-rule interpreter, not an LLM or E12 evidence."""
    descriptor = "offline-analytical-fixture-v2"

    def propose(self, request):
        data = json.loads(request.context_json)
        operations, lessons, memories = ["READ_SOURCE", "DRAFT"], [], []
        for block in data["blocks"]:
            memories.extend(block["source_memory_ids"])
            if block["kind"] == "LESSON":
                lesson = json.loads(block["data_json"])
                if lesson["rule"].get("required_output") == "locator":
                    operations = ["READ_SOURCE", "LOCATE_SOURCE", "DRAFT"]
                    lessons.append(lesson["lesson_id"])
        return CognitiveProposal(identity_id=data["manifest"]["identity_id"],
            identity_revision=data["manifest"]["identity_revision"],
            interpretation="Use supplied current evidence and scoped procedures; no execution authority.",
            proposed_operations=tuple(operations), memory_refs=tuple(dict.fromkeys(memories))[:64],
            lesson_refs=tuple(lessons)).model_dump_json()


class CautiousFixturePort:
    """A second fixture planner: absent evidence asks, contradictions defer."""
    descriptor = "offline-cautious-fixture-v2"

    def propose(self, request):
        data = json.loads(request.context_json)
        blocks = data["blocks"]
        memories = tuple(dict.fromkeys(m for b in blocks for m in b["source_memory_ids"]))[:64]
        lessons = [json.loads(b["data_json"]) for b in blocks if b["kind"] == "LESSON"]
        if any(b["kind"] == "UNRESOLVED_CONFLICT" for b in blocks):
            operations = ("ASK",)
        elif not memories:
            operations = ("WAIT",)
        else:
            operations = ("READ_SOURCE", "DRAFT")
            if any(x["rule"].get("capability") == "reading.source.locate" for x in lessons):
                operations = ("READ_SOURCE", "LOCATE_SOURCE", "DRAFT")
        return CognitiveProposal(identity_id=data["manifest"]["identity_id"],
            identity_revision=data["manifest"]["identity_revision"],
            interpretation="Separate known history from uncertainty; resolve conflict before drafting.",
            proposed_operations=operations, memory_refs=memories,
            lesson_refs=tuple(x["lesson_id"] for x in lessons) if "LOCATE_SOURCE" in operations else ()).model_dump_json()
