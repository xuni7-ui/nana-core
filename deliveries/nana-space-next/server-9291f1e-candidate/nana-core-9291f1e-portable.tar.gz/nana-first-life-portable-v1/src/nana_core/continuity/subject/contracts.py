"""C-stage subject contracts. No executable authority and no real ingress switch."""
from typing import Literal,get_args
from pydantic import Field, model_validator,model_serializer
from ...contracts import DTO
from .social import SocialInteractionProposal
from .opportunities import Behavior,SyntheticActionProposal,PrivateIntentRef,LearningProgramOption
from ..autonomy.contracts import DisclosureRequest,DisclosureDecision,SubjectEvaluation,RealizationTarget,RelationshipDetails,PositiveRequest,RequestDecision
from ..extensions import SurfaceEnvelope
from ..agency_contracts import GoalStepRef,GoalReviewRef

from ..relational.contracts import RelationalRequest,RelationalDecision,FacetName

from .context_fit import InteractionSignal,ContextFitAssessment
from .framing import ProblemFrame,FrameAssessment
from .experience_need import ExperienceNeed

Key = str
Level = Literal['NONE', 'LOW', 'RELEVANT', 'HIGH']
DAY_US = 86_400_000_000
MAX_PENDING = 8
INTENTION_TTL_US = 7 * DAY_US


class PreferenceSignal(DTO):
    kind: Literal['PREFERENCE', 'SELF_BELIEF', 'PERSONALITY_TENDENCY'] = 'PREFERENCE'
    topic: str = Field(pattern=r'^[a-z][a-z0-9._-]{0,63}$')
    direction: Literal['SUPPORT', 'COUNTER']
    interpretation: str = Field(min_length=1, max_length=512)

    @model_validator(mode='after')
    def personality_topic(self):
        if self.kind=='PERSONALITY_TENDENCY' and self.topic not in {'personality.'+f for f in get_args(FacetName)}:raise ValueError('unknown personality facet')
        return self


from ..person_self import ConversationProposal, ConversationDecision
from ...life.dialogue_contracts import CommunicationChoice

class SubjectInput(DTO):
    communication_method_record_id:str|None=Field(default=None,pattern=r'^[A-Za-z0-9._:-]{1,128}$')
    private_thought_ref:PrivateIntentRef|None=None
    conversation_proposal: ConversationProposal | None = None
    problem_frame: ProblemFrame | None = None
    interaction_signal: InteractionSignal | None = None
    growth_assessment_id: str | None = None
    schema_version: Literal[1] = 1
    domain: Literal['SYNTHETIC_ONLY','DEVELOPMENT_MATERIAL','LOCAL_INTERACTION','SOURCED_LIFE'] = 'SYNTHETIC_ONLY'
    source_key: str = Field(pattern=r'^(?:synthetic|development|local)[.:_-][A-Za-z0-9._:-]{1,128}$')
    surface: SurfaceEnvelope | None = None
    goal_step: GoalStepRef | None = None
    goal_review: GoalReviewRef | None = None
    world_concern_id: str | None = None
    memory_review_id: str | None = None
    kind: Literal['INTERACTION', 'PROJECT', 'PLAY', 'OUTCOME', 'WAKE', 'RELATIONSHIP', 'REFLECTION']
    origin: Literal['USER', 'ENVIRONMENT', 'SELF_WAKE']
    entity_id: str = Field(pattern=r'^[A-Za-z0-9._:-]{1,128}$')
    scope: str = Field(pattern=r'^[A-Za-z0-9._:-]{1,128}$')
    occurred_at_us: int | None = Field(default=None, ge=0)
    observed_at_us: int = Field(ge=0)
    text: str | None = Field(default=None, max_length=8192)
    privacy_class: Literal['PUBLIC', 'PROJECT', 'PERSONAL', 'SECRET'] = 'PERSONAL'
    retention: Literal['MAY_REMEMBER', 'DO_NOT_REMEMBER'] = 'MAY_REMEMBER'
    source_memory_ids: tuple[str, ...] = Field(default=(), max_length=32)
    topic: str | None = Field(default=None, pattern=r'^[a-z][a-z0-9._-]{0,63}$')
    novelty: Level = 'LOW'
    significance: Level = 'LOW'
    risk: Level = 'NONE'
    urgency: Level = 'NONE'
    uncertainty: Level = 'LOW'
    proposed_method: str | None = Field(default=None, max_length=128)
    constraint_memory_ids: tuple[str, ...] = Field(default=(), max_length=16)
    preference_signal: PreferenceSignal | None = None
    relationship_kind: Literal['SHARED_HISTORY', 'SHARED_PROJECT', 'SHARED_JOKE', 'NORM', 'BOUNDARY', 'CONFLICT', 'REPAIR', 'TRUST', 'COMMITMENT'] | None = None
    task_class: str | None = Field(default=None, pattern=r'^[A-Za-z0-9._:-]{1,96}$')
    reflection_experience_id: str | None = None
    result_for_intention_id: str | None = None
    observed_availability: Literal['AVAILABLE','BUSY','UNKNOWN'] | None = None
    disclosure_request: DisclosureRequest | None = None
    realization_target: RealizationTarget | None = None
    governance_review_id: str | None = None
    relationship_details: RelationshipDetails | None = None
    positive_request: PositiveRequest | None = None
    commitment_check_id: str | None = None
    disposition_reflection_id: str | None = None
    relational_request: RelationalRequest | None = None

    @model_serializer(mode='wrap')
    def preserve_legacy_input(self,handler):
        value=handler(self)
        if self.private_thought_ref is None:value.pop('private_thought_ref',None)
        if self.communication_method_record_id is None:value.pop('communication_method_record_id',None)
        return value

    @model_validator(mode='after')
    def provenance(self):
        if self.communication_method_record_id is not None:
            if (self.kind!='WAKE' or self.origin!='SELF_WAKE' or self.retention=='DO_NOT_REMEMBER'
                    or self.task_class!='interaction.method.consider' or any((self.private_thought_ref,self.world_concern_id,
                        self.goal_step,self.goal_review,self.memory_review_id,self.reflection_experience_id,self.growth_assessment_id))):
                raise ValueError('an own method consideration requires one retained self wake')
        if self.private_thought_ref is not None and (self.kind!='WAKE' or self.origin!='SELF_WAKE' or self.retention=='DO_NOT_REMEMBER'):
            raise ValueError('private continuation requires a retained self wake, not a user command')
        if self.domain=='SOURCED_LIFE' and (self.origin!='SELF_WAKE' or self.kind!='WAKE' or not self.source_key.startswith('local.') or not self.source_memory_ids or self.text is not None):raise ValueError('sourced life wake requires retained sources, not a new user instruction')
        if self.problem_frame and not {c.memory_id for c in (*self.problem_frame.assumed,*self.problem_frame.required)} <= set(self.source_memory_ids):raise ValueError("framing requires explicit visible sources")
        if self.domain=='LOCAL_INTERACTION' and (not self.source_key.startswith('local.') or self.kind!='INTERACTION' or self.origin!='USER' or not self.text or not self.text.startswith('Local input reviewed meaning: ')):raise ValueError('local dialogue only carries normalized metadata')
        if self.domain=='DEVELOPMENT_MATERIAL' and (not self.source_key.startswith('development.') or self.privacy_class not in {'PUBLIC','PROJECT'}):raise ValueError('development sources require explicit nonprivate namespace')
        if self.interaction_signal and (self.kind!='INTERACTION' or self.origin!='USER' or not self.text or self.positive_request or self.relational_request):raise ValueError('interaction context requires a separate sourced user occurrence')
        if self.interaction_signal and self.topic and self.topic!=self.interaction_signal.topic_key:raise ValueError('context topic mismatch')
        if self.growth_assessment_id and any((self.world_concern_id,self.goal_step,self.goal_review,self.memory_review_id,self.reflection_experience_id)):raise ValueError('one sourced wake purpose')
        if self.growth_assessment_id and (self.kind!='WAKE' or self.origin!='SELF_WAKE' or not self.source_memory_ids):raise ValueError('growth review requires a sourced wake')
        if self.world_concern_id and (self.kind!="WAKE" or self.origin!="SELF_WAKE" or not self.source_memory_ids):raise ValueError("world concern requires sourced opportunity")
        if self.goal_review and (self.kind!='WAKE' or self.origin!='SELF_WAKE' or self.goal_step or self.memory_review_id or self.goal_review.cause_memory_id not in self.source_memory_ids):raise ValueError('review requires a separate source-backed opportunity')
        if self.goal_step and (self.kind!='WAKE' or self.origin!='SELF_WAKE' or not self.source_memory_ids):
            raise ValueError('plan step requires a source-backed internal opportunity')
        if self.memory_review_id and (self.kind!='WAKE' or self.origin!='SELF_WAKE' or self.goal_step or not self.source_memory_ids):
            raise ValueError('memory review requires a separate source-backed internal opportunity')
        if self.surface and (self.surface.entity_id != self.entity_id or self.surface.privacy_class != self.privacy_class
                or self.surface.observed_at_us != self.observed_at_us or self.surface.occurred_at_us != self.occurred_at_us):
            raise ValueError('surface metadata must match canonical input')
        if self.kind == 'WAKE':
            if self.origin != 'SELF_WAKE' or self.text or self.preference_signal or self.relationship_kind:
                raise ValueError('wake cannot manufacture experience')
        elif self.origin == 'SELF_WAKE':
            raise ValueError('self wake cannot claim external occurrence')
        if self.result_for_intention_id and (self.origin!='ENVIRONMENT' or self.kind!='OUTCOME' or not self.text):
            raise ValueError('synthetic intention outcome requires an observed world result')
        if self.preference_signal and not self.text:
            raise ValueError('preference signal requires an observed occurrence')
        if self.kind == 'REFLECTION':
            raise ValueError('reflection must reference an existing experience via SubjectLoop.reflect')
        if self.relationship_kind and not self.text:
            raise ValueError('relationship update requires a sourced occurrence')
        if self.relationship_kind and self.kind not in {'RELATIONSHIP', 'PROJECT', 'INTERACTION'}:
            raise ValueError('relationship occurrence kind mismatch')
        if self.relationship_details and not self.relationship_kind:raise ValueError('relationship metadata requires occurrence')
        if self.relationship_details and self.relationship_details.social_expectation and self.relationship_kind not in {'BOUNDARY','NORM'}:raise ValueError('social expectation requires explicit norm/boundary')
        if self.relational_request and (self.origin!='USER' or not self.text or self.relational_request.requesting_entity!=self.entity_id):raise ValueError('relational request requires sourced requesting entity')
        if self.positive_request and (self.origin!='USER' or not self.text):raise ValueError('positive request must be a sourced user request')
        if self.commitment_check_id and self.kind!='WAKE':raise ValueError('commitment check is a wake opportunity')
        if sum(x is not None for x in (self.positive_request,self.governance_review_id,self.disposition_reflection_id,self.relational_request))>1:raise ValueError('one deliberation purpose per event')
        return self


class Appraisal(DTO):
    novelty: Level
    goal_relevance: Level
    relationship_relevance: Level
    self_relevance: Level
    unfinished_tension: Level
    interest_relevance: Level
    risk: Level
    conflict: Level
    urgency: Level
    expected_value: Level
    uncertainty: Level
    privacy_relevance: Level
    source_ids: tuple[str, ...]
    reasons: tuple[str, ...]


class Motivation(DTO):
    source: str = Field(pattern=r'^[A-Z][A-Z0-9_]{1,63}$')
    strength: Literal['AVAILABLE','RELEVANT','PRESSING']
    source_ids: tuple[str, ...]
    inhibited_by: tuple[str, ...] = ()


class Judgment(DTO):
    stance: Literal['AGREE','PARTIAL_AGREE','DISAGREE','ALTERNATIVE','IGNORE','WATCH','REMEMBER','ASK','THINK_MORE','DEFER','REFLECT']
    reason: str = Field(min_length=1, max_length=1024)
    source_ids: tuple[str, ...]
    selected_method: str | None = None
    lesson_ids: tuple[str, ...] = ()


class Intention(DTO):
    kind: Literal['NO_ACTION','SOCIAL_INTERACTION','MEMORY_CANDIDATE','REFLECTION','GOAL_CANDIDATE','ACTION_PROPOSAL','WAIT','EXPLORE','DISAGREE']
    purpose: str = Field(min_length=1, max_length=512)
    slot_key: str = Field(pattern=r'^[A-Za-z0-9._:-]{1,128}$')
    source_ids: tuple[str, ...]
    self_generated: bool
    behavior: Behavior | None = None


class DeliberationFrame(DTO):
    """Pre-model appraisal/attention, not model truth or an adopted intention."""
    derived: Literal[True] = True
    subject_event_id: str
    scope: str
    appraisal: Appraisal
    motivations: tuple[Motivation, ...]
    attention: Literal['FOCUS_NOW','BACKGROUND_WATCH','DEFER','IGNORE','RECALL_LATER']
    source_memory_ids: tuple[str, ...]
    source_record_ids: tuple[str, ...]
    behavior_options:tuple[Behavior,...]=Field(default=(),max_length=8)
    learning_programs:tuple[LearningProgramOption,...]=Field(default=(),max_length=16)

    @model_serializer(mode='wrap')
    def compatible_options(self,handler):
        result=handler(self)
        if not self.behavior_options:result.pop('behavior_options',None)
        if not self.learning_programs:result.pop('learning_programs',None)
        return result


class DeliberationTrace(DTO):
    model_descriptor: str = Field(min_length=1, max_length=128)
    context_digest: str
    raw_proposal_json: str = Field(max_length=32768)
    source_kind: Literal['MODEL_PROPOSAL_NOT_TRUTH'] = 'MODEL_PROPOSAL_NOT_TRUTH'


class CycleResult(DTO):
    communication_choice:CommunicationChoice|None=None
    conversation_decision: ConversationDecision | None = None
    experience_need: ExperienceNeed | None = None
    problem_frame: FrameAssessment | None = None
    context_fit: ContextFitAssessment | None = None
    cycle_id: str
    event_id: str
    revision: int
    admission: Literal['KEEP','MERGE','TEMPORARY','IGNORE','FORGET_LATER']
    appraisal: Appraisal
    motivations: tuple[Motivation, ...]
    attention: Literal['FOCUS_NOW','BACKGROUND_WATCH','DEFER','IGNORE','RECALL_LATER']
    judgment: Judgment
    intention: Intention
    intention_id: str | None
    goal_candidate_id: str | None
    barrier: Literal['NO_ACTION','SHADOW_BLOCKED']
    record_id: str | None
    replayed: bool = False
    proposed_program_id: str | None = None
    selected_memory_candidate_id: str | None = None
    deliberation: DeliberationTrace | None = None
    social_proposal: SocialInteractionProposal | None = None
    action_proposal: SyntheticActionProposal | None = None
    evaluation: SubjectEvaluation | None = None
    disclosure: DisclosureDecision | None = None
    realization_target: RealizationTarget | None = None
    request_decision: RequestDecision | None = None
    selected_disposition_id: str | None = None
    relational_decision: RelationalDecision | None = None

    @model_serializer(mode='wrap')
    def compatible_choice_wire(self,handler):
        value=handler(self)
        if self.communication_choice is None:value.pop('communication_choice',None)
        return value


class WakeCondition(DTO):
    kind: Literal['INCOMING_EVENT','TIME_TRIGGER','GOAL_TRIGGER','ANOMALY','RELATIONSHIP_TRIGGER','SELF_TRIGGER','REFLECTION_TRIGGER','DEVICE_TRIGGER','ENVIRONMENT_CHANGE']
    due_at_us: int = Field(ge=0)
    source_ids: tuple[str, ...] = Field(min_length=1, max_length=32)
    dedupe_key: str = Field(min_length=1, max_length=128)


class StandingDelegation(DTO):
    """Future E contract; C never registers or activates one."""
    delegation_id: str
    subject: str
    capability: str = Field(min_length=1, max_length=128, pattern=r'^[A-Za-z0-9._:-]+$')
    resource_scope: tuple[str, ...] = Field(min_length=1, max_length=16)
    operations: tuple[str, ...] = Field(min_length=1, max_length=16)
    risk_ceiling: Literal['READ_ONLY','REVERSIBLE','EXPLICIT_ONLY']
    privacy_scope: tuple[Literal['PUBLIC','PROJECT','PERSONAL'], ...]
    issued_at_us: int = Field(ge=0)
    expires_at_us: int = Field(ge=0)
    revoked: bool = False
    provenance: str = Field(min_length=1, max_length=256)

    @model_validator(mode='after')
    def exact(self):
        if self.expires_at_us <= self.issued_at_us or any('*' in s for s in (*self.resource_scope, *self.operations)):
            raise ValueError('exact, finite delegation required')
        return self
