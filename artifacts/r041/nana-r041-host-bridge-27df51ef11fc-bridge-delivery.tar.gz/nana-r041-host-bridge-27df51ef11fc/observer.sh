#!/bin/sh
set -eu
base=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
python=$(command -v python3.12 || command -v python3) || exit 2
exec "$python" -I -B -S "$base/observer_entry.py" "$base" "$@"
