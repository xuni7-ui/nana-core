import{r as i,j as s}from"./index-Bc8I7C-o.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const j=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),o=(...e)=>e.filter((r,a,n)=>!!r&&r.trim()!==""&&n.indexOf(r)===a).join(" ").trim();/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var m={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const g=i.forwardRef(({color:e="currentColor",size:r=24,strokeWidth:a=2,absoluteStrokeWidth:n,className:c="",children:t,iconNode:d,...h},u)=>i.createElement("svg",{ref:u,...m,width:r,height:r,stroke:e,strokeWidth:n?Number(a)*24/Number(r):a,className:o("lucide",c),...h},[...d.map(([x,p])=>i.createElement(x,p)),...Array.isArray(t)?t:[t]]));/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const l=(e,r)=>{const a=i.forwardRef(({className:n,...c},t)=>i.createElement(g,{ref:t,iconNode:r,className:o(`lucide-${j(e)}`,n),...c}));return a.displayName=`${e}`,a};/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f=l("ArrowUpRight",[["path",{d:"M7 7h10v10",key:"1tivn9"}],["path",{d:"M7 17 17 7",key:"1vkiza"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const b=l("Search",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const k=l("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]);function w({children:e,tone:r="purple"}){return s.jsx("span",{className:`badge ${r}`,children:e})}function y({children:e,className:r=""}){return s.jsx("section",{className:`panel ${r}`,children:e})}function N({eyebrow:e,title:r,description:a,children:n}){return s.jsxs("div",{className:"section-heading",children:[s.jsxs("div",{children:[e&&s.jsx("span",{className:"eyebrow",children:e}),s.jsx("h2",{children:r}),a&&s.jsx("p",{children:a})]}),n]})}function A({eyebrow:e,title:r,description:a,children:n}){return s.jsxs("div",{className:"page-heading",children:[s.jsxs("div",{children:[s.jsx("span",{className:"eyebrow",children:e}),s.jsxs("h1",{children:[r,s.jsx("span",{className:"heading-star",children:" ✧"})]}),s.jsx("p",{children:a})]}),n]})}function C({value:e}){return s.jsx("div",{className:"progress",role:"progressbar","aria-valuenow":e,"aria-valuemin":0,"aria-valuemax":100,children:s.jsx("span",{style:{width:`${e}%`}})})}function E({title:e,description:r}){return s.jsxs("div",{className:"empty",children:[s.jsx("span",{children:"✧"}),s.jsx("h3",{children:e}),s.jsx("p",{children:r})]})}function $({value:e,onChange:r,placeholder:a}){return s.jsxs("label",{className:"search-field",children:[s.jsx(b,{size:17}),s.jsx("input",{"aria-label":a,value:e,onChange:n=>r(n.target.value),placeholder:a}),e&&s.jsx("button",{"aria-label":"清空搜索",onClick:()=>r(""),children:s.jsx(k,{size:16})})]})}function L({children:e,onClick:r}){return s.jsxs("button",{className:"text-link",onClick:r,children:[e,s.jsx(f,{size:15})]})}export{f as A,w as B,E,A as P,N as S,L as T,k as X,y as a,C as b,l as c,$ as d};
