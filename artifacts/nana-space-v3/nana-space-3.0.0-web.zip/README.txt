Nana Space V3 live Web client

Source: fde9074c30c81854fc1a8786433014079e28b94d
Use a same-origin authenticated V2 BFF with HTTPS. This archive contains only Web assets, not a Core Subject or server credentials. Replacing a cloud image/Web deployment is separately approved; the original qualified image is unchanged.
Offline inspection: extract and run a loopback static server rooted at web/; without BFF, explicitly choose offline browsing. Never treat offline preview as a production connection.
See docs/nana_space_v3/ for source/interface/status and test evidence.
