Nana adapter-local ENGINEERING SHADOW. No AstrBot hook or takeover.
Verify the uploaded archive SHA256 against the separately provided receipt before extraction.
Existing CPython3.12 normal ABI/SOABI cpython-312-x86_64-linux-gnu, Linux x86_64, glibc>=2.34 required.
Full regression measured3.12.3 and3.12.14; other patches UNTESTED. No system install.
./run_shadow.sh preflight --dry-run
./run_shadow.sh preflight
./run_shadow.sh probe
./run_shadow.sh restart-check
./run_shadow.sh rollback
./run_shadow.sh collect
Optional interpreter: ./run_shadow.sh --python /reviewed/python preflight
Every script supports --dry-run. Only data/ is mutable, all other files hash checked before import.
Stop from another terminal: ./stop_shadow.sh
No API key, secret, model call, production Action or Iris write is configured.
Dynamic AstrBot hook and real-host binding remain UNKNOWN/NOT_RUN.
