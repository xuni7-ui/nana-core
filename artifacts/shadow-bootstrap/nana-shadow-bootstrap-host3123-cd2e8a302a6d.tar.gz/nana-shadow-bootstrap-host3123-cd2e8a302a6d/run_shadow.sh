#!/bin/sh
set -eu
base=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
if [ "${1:-}" = "--python" ]; then
    test "$#" -ge 3 || exit 2
    python=$2
    shift 2
else
    python=$(command -v python3.12 || command -v python3) || exit 2
fi
exec "$python" -I -B -S "$base/package/support/nana_host_shadow/bootstrap_entry.py" "$base" "$@"
